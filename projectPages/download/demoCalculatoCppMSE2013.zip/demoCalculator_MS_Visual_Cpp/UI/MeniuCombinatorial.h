#ifndef MENIUCOMBINATORIAL
#define MENIUCOMBINATORIAL

#include "Meniu.h"

namespace Calculator{
namespace UI{
          
class MeniuCombinatorial: public Meniu
      {
       public:
       MeniuCombinatorial();
      };      

class MeniuOperatiiAritmetice: public Meniu
      {
       public:
       MeniuOperatiiAritmetice();
      };
}}

#endif
