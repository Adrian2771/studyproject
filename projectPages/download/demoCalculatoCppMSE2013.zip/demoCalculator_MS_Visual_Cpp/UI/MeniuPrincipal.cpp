#include "MeniuPrincipal.h"
#include "MeniuCombinatorial.h"
#include "MeniuSiruri.h"

namespace Calculator{
namespace UI{
MeniuPrincipal::MeniuPrincipal(): Meniu("Lista Optiuni")
{
 AdaugaComanda(new MeniuCombinatorial());
 AdaugaComanda(new MeniuSiruri());
 AdaugaComanda(new MeniuOperatiiAritmetice());
}

}}
