// cmdcombinatorial.h

#ifndef CMDCOMBINATORIAL_H
#define CMDCOMBINATORIAL_H

#include <iostream>

#include "../Calcule/exceptii.h"
#include "../util.h"


using namespace Calculator::Calcule;

namespace Calculator{
namespace UI{

template <int Operatie(int)>
class CmdCombinatorial1: public Comanda
{
      public:
      CmdCombinatorial1(const string &nume): Comanda(nume) {}
      void Execute()
      {
      try{
           cout <<"\nIntroduceti un numar intreg in intervalul [0, " << MAX << "]." << endl;
           int n;
           cin >> n;
           cout << Nume() << "(" << n << ") = " << Operatie(n) << endl;
         }
      catch(const InvalidN&)
         {
           cout <<"\nValoarea introdusa este invalida." << endl;
         }
         AsteaptaUser();
      }
};

template <int Operatie(int, int)>
class CmdCombinatorial2: public Comanda
{
      public:
      CmdCombinatorial2(const string &nume): Comanda(nume) {}
      void Execute()
      {
      try{
          cout <<"\nIntroduceti doua numere intregi (n, k, k <= n) in intervalul [0, " << MAX << "]:" <<endl;
          int n, k;
          cout <<"n: ";
          cin >> n;
          cout <<"k: ";
          cin >> k;
          cout << Nume() << "(" << n << ", " << k << ") = " << Operatie(n,k) << endl;
         }
      catch(const InvalidN&)
         {
          cout <<"\nValoarea introdusa pentru n este invalida." << endl;
         }
      catch(const InvalidK&)
         {
           cout <<"\nValoarea introdusa pentru k este invalida." << endl;
         }
         AsteaptaUser();
      }
};

template <typename T, T Operatie(int, int)>
class BasicOps: public Comanda
{
      public:
      BasicOps(const string &nume): Comanda(nume) {}
      void Execute()
      {
           try
           {
            cout <<"\nIntroduceti doua numere intregi n, k pentru operatii elementare." << endl;
            int n, k;
            cout <<"n: ";
            cin >> n;
            cout <<"k: ";
            cin >> k;
            cout << Nume() << "(" << n << ", " << k << ") = " << Operatie(n,k) << endl;
           }
           catch(const ImpartireLaZero&)
           {
            cout <<"\nImpartirea la zero este interzisa." << endl;
           }
           AsteaptaUser();
      }
};
            
      
}}
#endif
