// clasa Comanda
#ifndef COMANDA_H
#define COMANDA_H

#include <string>

using std::string;

namespace Calculator{
namespace UI{
          
class Comanda
{
      const string _nume; 
      public:
      Comanda(const string &nume);
      virtual ~Comanda();
      
      const string& Nume() const; 
      virtual void Execute() = 0;
};
          
}}
          
#endif
