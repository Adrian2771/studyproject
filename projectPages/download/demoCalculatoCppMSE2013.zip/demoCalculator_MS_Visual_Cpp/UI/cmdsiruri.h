#ifndef CMDSIRURI_H
#define CMDSIRURI_H
#include "Comanda.h"

#include <iostream>

#include "../Calcule/exceptii.h"
#include "../util.h"


using namespace Calculator::Calcule;

namespace Calculator{
namespace UI{

template<typename SirNumere, int MAX, int MIN = 0>
class CmdSiruri: public Comanda
{
      SirNumere _sir;
      public:
      CmdSiruri(const string &nume): Comanda(nume){}
      void Execute()
      {
       try
       {
           std::cout <<"\nIntroduceti un numar intreg in intervalul [0, " << MAX <<"]:" << std::endl;
           int n;
           cin >> n;
           std::cout << "Sirul " << Nume() << " [0 - " << n << "):\n" << _sir(n) << std::endl;
       }
       catch(const ParametruInAfaraIntervalului&)
       {
           std::cout <<"\nParametrul este in afara intervalului permis." << std::endl;
       }
       AsteaptaUser();
      }
};    
}}

#endif
