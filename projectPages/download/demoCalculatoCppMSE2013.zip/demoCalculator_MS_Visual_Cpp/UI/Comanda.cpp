//implementare Comanda

#include "Comanda.h"

namespace Calculator{
namespace UI{

Comanda::Comanda(const string &nume): _nume(nume)
{
}

Comanda::~Comanda()
{
}

const string& Comanda::Nume() const
        {
            return _nume;
        }
}}
