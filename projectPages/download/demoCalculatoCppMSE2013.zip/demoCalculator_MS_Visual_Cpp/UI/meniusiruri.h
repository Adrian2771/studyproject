#ifndef MENIUSIRURI_H
#define MENIUSIRURI_H

#include "Meniu.h"

namespace Calculator{
namespace UI{
class MeniuSiruri: public Meniu
{
      public:
      MeniuSiruri();
};
}}

#endif
