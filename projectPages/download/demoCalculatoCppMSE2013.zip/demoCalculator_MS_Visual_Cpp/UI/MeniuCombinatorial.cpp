#include "MeniuCombinatorial.h"
#include "../Calcule/combinatorial.h"
#include "cmdcombinatorial.h"

namespace Calculator{
namespace UI{

MeniuCombinatorial::MeniuCombinatorial(): Meniu("Combinatorial")
{
 AdaugaComanda(new CmdCombinatorial1<Factorial>("Factorial"));
 AdaugaComanda(new CmdCombinatorial2<Aranjamente>("Aranjamente"));
 AdaugaComanda(new CmdCombinatorial2<Combinari>("Combinari"));
}

MeniuOperatiiAritmetice::MeniuOperatiiAritmetice(): Meniu("Operatii aritmetice")
{
 AdaugaComanda(new BasicOps<int, Adunare>("Adunare"));
 AdaugaComanda(new BasicOps<int, Scadere>("Scadere"));
 AdaugaComanda(new BasicOps<int, Inmultire>("Inmultire"));
 AdaugaComanda(new BasicOps<double, Impartire>("Impartire"));
 AdaugaComanda(new BasicOps<int, Modulo>("Modulo"));
}
}}
