#include "meniusiruri.h"
#include "cmdsiruri.h"
#include "../Calcule/siruri.h"

namespace Calculator{
namespace UI{

MeniuSiruri::MeniuSiruri(): Meniu("Siruri Numerice")
{
 AdaugaComanda(new CmdSiruri<Fibonacci, Fibonacci::MAX_FIB>("Fibonacci"));
 AdaugaComanda(new CmdSiruri<Lucas, Lucas::MAX_LUCAS>("Lucas"));
 AdaugaComanda(new CmdSiruri<Pell, Pell::MAX_PELL>("Pell"));
 AdaugaComanda(new CmdSiruri<Triangular, Triangular::MAX_TRIANGULAR>("Triangular"));
 AdaugaComanda(new CmdSiruri<Pentagonal, Pentagonal::MAX_PENTAGONAL>("Pentagonal"));
}

}}
 
