#include "aplicatie.h"
#include "UI/MeniuPrincipal.h"

using namespace Calculator::UI;

namespace Calculator{

void Aplicatie::Run()
{
 MeniuPrincipal meniuPrincipal;
 do{
    meniuPrincipal.Execute();
   }
 while(meniuPrincipal.Exit() == false);
}
}
