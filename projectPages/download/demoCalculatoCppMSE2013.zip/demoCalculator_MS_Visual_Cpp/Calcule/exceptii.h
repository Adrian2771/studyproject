//Exceptii
#ifndef EXCEPTII_H
#define EXCEPTII_H

namespace Calculator{
namespace Calcule{
          
struct ImpartireLaZero {};
struct ParametruInAfaraIntervalului {};
struct InvalidK {};
struct InvalidN {};
}}

#endif
