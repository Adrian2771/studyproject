//Combinatorial declaratii

#ifndef COMBINATORIAL_H
#define COMBINATORIAL_H

#define MAX 12

namespace Calculator{
namespace Calcule{

int Factorial(int n);
int Aranjamente(int n, int k);
int Combinari(int n, int k);

//operatii aritmetice

int Adunare(int, int);
int Scadere(int, int);
int Inmultire(int, int);
int Modulo(int, int);
double Impartire(int, int);

}}

#endif