#include "siruri.h"
#include <iomanip>
#include "exceptii.h"

namespace Calculator{
namespace Calcule{

Uint Sir::operator [] (Uint index) const
{
     if(index <0 || index >= _count)
     {
      throw ParametruInAfaraIntervalului();
     }
     return _elemente[index];
}

Sir& Sir::operator () (Uint count)
{
     _count = count;
     CalculeazaValori(_count);
     return *this;
}

ostream& operator << (ostream &out, const Sir &sir)
{
     Uint DIM = sir._count;
     out <<"Index" <<"\tEelemente" << endl;
     for(Uint i = 0; i < DIM; i++)
     {
      out << setw(4) << right << i << setw(12) << right << sir[i] << endl; 
     } 
     return out;
}     
     
void Fibonacci::CalculeazaValori(Uint count)
   {
        if(count > MAX_FIB) throw ParametruInAfaraIntervalului();
        if(0 == _elemente.size())
        {
         _elemente.push_back(0);
         _elemente.push_back(1);
        }
        Uint i = _elemente.size();
        while(i < count)
        {
         _elemente.push_back(_elemente[i-1] +_elemente[i-2]);
        i = _elemente.size(); // se putea incrementa i in loc de apel
        }
   }
   
   void Lucas::CalculeazaValori(Uint count)
   {
        if(count > MAX_LUCAS) throw ParametruInAfaraIntervalului();
        if(0 == _elemente.size())
        {
         _elemente.push_back(2);
         _elemente.push_back(1);
        }
        Uint i = _elemente.size();
        while(i < count)
        {
         _elemente.push_back(_elemente[i-1] +_elemente[i-2]);
        i = _elemente.size(); // se putea incrementa i in loc de apel
        }
   }
   
   void Pell::CalculeazaValori(Uint count)
   {
        if(count > MAX_PELL) throw ParametruInAfaraIntervalului();
        if(0 == _elemente.size())
        {
              _elemente.push_back(0);
              _elemente.push_back(1);
        }
        Uint init = _elemente.size();
        for(Uint i = init; i < count;)
        {
        _elemente.push_back(2 * _elemente[i - 1] + _elemente[i - 2]);
        i = _elemente.size(); 
        }
   }
        
   
   void Triangular::CalculeazaValori(Uint count)
   {
        if(count > MAX_TRIANGULAR) throw ParametruInAfaraIntervalului();
        if(0 == _elemente.size())
        {
              _elemente.push_back(0);
        }
        Uint init = _elemente.size();
        for(Uint i = init; i < count;)
        {
         _elemente.push_back(i*(i + 1)/2);
         i = _elemente.size(); // putea fi incrementat i in loc de apel
        } 
   } 
   
   void Pentagonal::CalculeazaValori(Uint count)
   {
        if(count > MAX_PENTAGONAL) throw ParametruInAfaraIntervalului();
        if(0 == _elemente.size())
        {
              _elemente.push_back(0);
        }
        Uint init = _elemente.size();
        for(Uint i = init; i < count;)
        {
         _elemente.push_back(i*(3*i - 1)/2);
         i = _elemente.size(); // putea fi incrementat i in loc de apel
        }
   }
     }}
