// definitii siruri

#ifndef SIRURI_H
#define SIRURI_H

#include <vector>

using namespace std;

typedef unsigned int Uint;
typedef vector<Uint> TVint;
typedef vector<Uint>::const_iterator TIterator;


namespace Calculator{
namespace Calcule
{
class Sir
{
      protected:
      Uint _count; 
      TVint _elemente;
      public:
      Sir(): _count(0) {}
      virtual ~Sir() {};
      Uint operator [] (Uint index) const;
      Sir& operator () (Uint count);
      protected:
      virtual void CalculeazaValori(Uint count) = 0;
      
      friend ostream& operator << (ostream &out, const Sir &sir);
};

class Fibonacci: public Sir
  {     
        protected:
        void CalculeazaValori(Uint count);
        public:
        Fibonacci(): Sir() {}
        //Uint Size () const {return _elemente.size();}
        enum { MAX_FIB = 48 };  
  };
  
  class Lucas: public Sir
  {
        protected:
        void CalculeazaValori(Uint count);
        public:
        Lucas(): Sir() {}
        enum {MAX_LUCAS = 47 };
  };
        
  class Pell: public Sir
  {
        protected:
        void CalculeazaValori(Uint count);
        public:
        Pell(): Sir() {}
        enum {MAX_PELL = 27 };
  };
  
  class Triangular: public Sir
  {
        protected:
        void CalculeazaValori(Uint count);
        public:
        Triangular(): Sir() {}
        enum {MAX_TRIANGULAR = 1024 };
  };
  
  class Pentagonal: public Sir
  {
        protected:
        void CalculeazaValori(Uint count);
        public:
        Pentagonal(): Sir() {}
        enum {MAX_PENTAGONAL = 1024 };
  };
        
}}

#endif
