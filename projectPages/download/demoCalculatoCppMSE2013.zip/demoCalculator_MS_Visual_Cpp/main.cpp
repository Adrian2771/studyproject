#include "aplicatie.h"
using namespace Calculator;

int main ()
{
    Aplicatie app;
    app.Run();
    
    return 0;
}
