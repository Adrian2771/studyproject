#ifndef APLICATIE_H
#define APLICATIE_H

namespace Calculator{
    class Aplicatie
    {
    public:
        void Run();

    };

}

#endif
